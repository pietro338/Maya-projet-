
function checkPassword() {
    const password = document.getElementById('password').value;
    if (password === 'KATUN XIII') {
        window.location.href = 'portail.html';
    } else {
        alert('Mot sacré incorrect.');
    }
}
